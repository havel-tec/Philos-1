<?php
session_start();
$obterdominio = $_SESSION['dominio'];
include('../' . $obterdominio . '/' . 'conexao.php');
$codigo = $_POST['codigo'];
$cod = $_POST['cod'];
?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

<div id="carregar-listar-usuarios-tarefas"></div>

<table class="table">




	<?php

	mysqli_query($conexao, "SET NAMES 'utf8'");
	mysqli_query($conexao, 'SET character_set_connection=utf8');
	mysqli_query($conexao, 'SET character_set_client=utf8');
	mysqli_query($conexao, 'SET character_set_results=utf8');
	$selecao = mysqli_query($conexao, "select * from tarefas_atividades_workflow WHERE id='$codigo' LIMIT 1");
	while ($registros = mysqli_fetch_array($selecao)) {
		$codigo_tarefa = $registros['id'];
	?>

		<tr>
			<th><label>Tarefa</label>
				<h4>
					<input type="text" value="<?php echo $registros['tarefa']; ?>" class="form-control" id="tarefa">
				</h4>
			</th>

		</tr>


		<tr>
			<th><label>Plano de Ação</label>
				<h4>
					<input type="text" value="<?php echo $registros['planoAcao']; ?>" class="form-control" id="planoAcao">
				</h4>
			</th>

		</tr>



		<tr>
			<th><label>Item Qaa</label>
				<h4>
					<input type="text" value="<?php echo $registros['itemQaa']; ?>" class="form-control" id="itemQaa">
				</h4>
			</th>

		</tr>
		<tr>
			<th><label>Responsável Processo</label>
				<h4>
					<input type="text" value="<?php echo $registros['responProc']; ?>" class="form-control" id="responProc">
				</h4>
			</th>

		</tr>
		<tr>
			<th><label>Responsável Ação</label>
				<h4>
					<input type="text" value="<?php echo $registros['responAcao']; ?>" class="form-control" id="responAcao">
				</h4>
			</th>

		</tr>
		<tr>
			<th><label>Departamento</label>
				<h4>
					<input type="text" value="<?php echo $registros['area']; ?>" class="form-control" id="area">
				</h4>
			</th>

		</tr>
		<tr>
			<th><label>Planta</label>
				<h4>
					<input type="text" value="<?php echo $registros['empresa']; ?>" class="form-control" id="empresa">
				</h4>
			</th>

		</tr>
		<tr>
			<th><label>Data Envio Plano de Ação</label>
				<h4>
					<input type="date" value="<?php echo $registros['dtEnvioPlanoAcao']; ?>" class="form-control" id="dtEnvioPlanoAcao">
				</h4>
			</th>

		</tr>
		<tr>
			<th><label>Data de Retorno com Prazo</label>
				<h4>
					<input type="date" value="<?php echo $registros['dtRetornoPrazo']; ?>" class="form-control" id="dtRetornoPrazo">
				</h4>
			</th>

		</tr>
		<tr>
			<th><label>Data da devolutiva</label>
				<h4>
					<input type="date" value="<?php echo $registros['dtDevolutiva']; ?>" class="form-control" id="dtDevolutiva">
				</h4>
			</th>

		</tr>
		<tr>
			<th><label>Dias de atraso para retorno com o prazo</label>
				<h4>
					<input type="number" value="<?php echo $registros['diasRetPrazo']; ?>" class="form-control" id="diasRetPrazo">
				</h4>
			</th>

		</tr>

		<div class="col-md-8 mt-3 mb-2">
			<label>Status prazo devolutiva:</label>

			<?php
			$statusDevolutiva = $registros['statusDevolutiva'];
			?>

			<select class="form-control" name="statusDevolutiva" id="statusDevolutiva">

				<?php if ($statusDevolutiva != '') { ?>

					<option selected><?php echo $registros['statusDevolutiva'] ?></option>
				<?php } ?>

				<?php if ($statusDevolutiva != 'Não iniciado') { ?>
					<option>Não iniciado</option>
				<?php } ?>

				<?php if ($statusDevolutiva != 'Em andamento') { ?>
					<option>Em andamento</option>
				<?php } ?>

				<?php if ($statusDevolutiva != 'Concluído]') { ?>
					<option>Concluído</option>
				<?php } ?>

			</select>

		</div>
		<tr>
			<th><label>Prazo para atendimento do plano de ação</label>
				<h4>
					<input type="date" value="<?php echo $registros['pzAtendPlanAcao']; ?>" class="form-control" id="pzAtendPlanAcao">
				</h4>
			</th>

		</tr>
		<tr>
			<th><label>Data de atendimento do plano de ação</label>
				<h4>
					<input type="date" value="<?php echo $registros['datAtendPlanAcao']; ?>" class="form-control" id="datAtendPlanAcao">
				</h4>
			</th>

		</tr>
		<tr>
			<th><label>Dias de atraso</label>
				<h4>
					<input type="numbner" value="<?php echo $registros['diasAtraso']; ?>" class="form-control" id="diasAtraso">
				</h4>
			</th>

		</tr>

		<div class="col-md-8 mt-3 mb-2">
			<label>Status prazo atedimento plano de ação:</label>

			<?php
			$statusPrazoPlanoAcao = $registros['statusPrazoPlanoAcao'];
			?>

			<select class="form-control" name="statusPrazoPlanoAcao" id="statusPrazoPlanoAcao">

				<?php if ($statusPrazoPlanoAcao != '') { ?>

					<option selected><?php echo $registros['statusPrazoPlanoAcao'] ?></option>
				<?php } ?>

				<?php if ($statusPrazoPlanoAcao != 'Não iniciado') { ?>
					<option>Não iniciado</option>
				<?php } ?>

				<?php if ($statusPrazoPlanoAcao != 'Em andamento') { ?>
					<option>Em andamento</option>
				<?php } ?>

				<?php if ($statusPrazoPlanoAcao != 'Concluído]') { ?>
					<option>Concluído</option>
				<?php } ?>

			</select>

		</div>


		<tr>

			<td>
				<label>Descrição</label>
				<textarea class="form-control" rows="10" id="cad-descricao"><?php echo $registros['descricao']; ?></textarea>
			</td>

		</tr>


		<tr>
			<td><label>Envolvido</label>
				<input type="text" class="form-control" name="cad-envolvido" id="cad-envolvido-tarefa" value="<?php echo $registros['envolvido'] ?>">
			</td>
		</tr>





	<?php } ?>

</table>


<h5>Anexos <img src="imgs/icone-mais.png" width="25" alt="" data-toggle="modal" data-target="#exampleModal" /></h5>
<div id="respostaarquivo"></div>
<div id="carrega-anexos"></div>
<table class="table">
	<?php
	$selecao2 = mysqli_query($conexao, "select * from upload_workflow WHERE codigo_cadastro='$codigo'");
	while ($registros2 = mysqli_fetch_array($selecao2)) {
	?>


		<tr>
			<td><img src="imgs/icone-documento.png" width="15" height="17" alt="" /> <?php echo $registros2['arquivo'] ?></td>
			<td>Arquivo enviado em: <?php echo $registros2['data'] ?> - <?php echo $registros2['hora'] ?></td>
			<td style="cursor: pointer" onClick="DeletarAnexo2(<?php echo $registros2['id'] ?>)"><strong><i class="fa fa-trash"></i></strong></td>
		</tr>


	<?php } ?>
</table>

<?php
$selecao = mysqli_query($conexao, "select * from tarefas_atividades_workflow WHERE id='$codigo'");
while ($registros = mysqli_fetch_array($selecao)) {
?>


	<div class="row">
		<div class="col-md-6">
			<label>Inicio</label>
			<input type="text" class="form-control datepicker" name="cad-inicio" id="cad-inicio" value="<?php

																										@$data_min = $registros['data_inicio'];
																										$ano_min = substr($data_min, 0, 4);
																										$mes_min = substr($data_min, 5, 2);
																										$dia_min = substr($data_min, 8, 2);

																										@$data_min = $dia_min . "/" . $mes_min . "/" . $ano_min;

																										echo	@$data_min;




																										?>" readonly>
		</div>

		<div class="col-md-6">
			<label>Término</label>
			<input type="text" class="form-control datepicker" name="cad-termino" id="cad-termino" value="<?php


																											@$data_max = $registros['data_termino'];
																											$ano_max = substr($data_max, 0, 4);
																											$mes_max = substr($data_max, 5, 2);
																											$dia_max = substr($data_max, 8, 2);

																											@$data_max = $dia_max . "/" . $mes_max . "/" . $ano_max;

																											echo @$data_max;



																											?>" readonly>
		</div>

		<div class="col-md-8 mt-3 mb-2">
			<label>Status:</label>

			<?php
			$status = $registros['status'];
			?>

			<select class="form-control" name="cad-status" id="cad-status">

				<?php if ($status != '') { ?>

					<option selected><?php echo $registros['status'] ?></option>
				<?php } ?>


				<?php if ($status != 'Não iniciado') { ?>
					<option>Não iniciado</option>
				<?php } ?>

				<?php if ($status != 'Em andamento') { ?>
					<option>Em andamento</option>
				<?php } ?>

				<?php if ($status != 'Concluído]') { ?>
					<option>Concluído</option>
				<?php } ?>

			</select>

		</div>



		<div class="col-md-4 mt-3">
			<label>Periodicidade</label>
			<select class="form-control" name="cad-periodicidade4" id="cad-periodicidade4">
				<option><?php echo $registros['periodicidade'] ?></option>
				<option>Diário</option>
				<option>Quinzenal</option>
				<option>Mensal</option>
				<option>Bimestral</option>
				<option>Trimestral</option>
				<option>Semestral</option>
				<option>Anual</option>
				<option>Bianual</option>
			</select>
		</div>


		<div class="col-md-12 mb-4 mt-3">
			<label>Área</label>
			<select class="form-control" name="cad-area-tarefa" id="cad-area-tarefa">

				<?php
				if ($registros['area'] != '') {
					$id_area = $registros['area'];
					$selecao_areas = mysqli_query($conexao, "select * from areas WHERE id='$id_area'");
					$reg = mysqli_fetch_array($selecao_areas);
				?>
					<option value="<?php echo $registros['area'] ?>"> <?php echo $reg['area'] ?></option>
				<?php } else { ?>
					<option value="0">Escolher</option>
				<?php } ?>

				<?php

				$selecao_areas = mysqli_query($conexao, "select * from areas order by area ASC");
				while ($registros_areas = mysqli_fetch_array($selecao_areas)) {

					if ($registros['area'] != $registros_areas['id']) {
				?>
						<option value="<?php echo $registros_areas['id'] ?>"><?php echo $registros_areas['area'] ?></option>

				<?php }
				} ?>
			</select>
		</div>

	</div>

<?php } ?>
<table class="table">
	<tr>
		<th>
			Responsáveis Tarefas <a onclick="AddResponsavel(<?php echo $codigo ?>)" data-toggle="modal" data-target="#ModalAddResponsavel" class="pointer">+</a>
		</th>
	</tr>

</table>


<div id="carregar-responsaveis-tarefas"></div>



<input type="button" class="btn btn-primary" value="Atualizar Tarefa" onClick="AtualizarTarefa(<?php echo $codigo ?>)">






<!-- Modal -->
<div class="modal fade" id="ModalAddResponsavel" tabindex="-1" role="dialog" aria-labelledby="ModalAddResponsavel" aria-hidden="true" style="z-index: 999999999">
	<div class="modal-dialog modal-dialog-centered" role="document" style="z-index: 999999999">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLongTitle">Responsáveis Tarefas</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<div id="resposta-modal"></div>

				<div id="carregar-listar-usuarios-atividades"></div>

			</div>
			<div class="modal-footer">
				<select class="form-control" id="novo-user">
					<option value="0">Novo usuário</option>
					<?php
					$selecao_usuarios = mysqli_query($conexao, "select * from usuarios_empresa");
					while ($registros_usuarios = mysqli_fetch_array($selecao_usuarios)) {
					?>

						<option value="<?php echo $registros_usuarios['id'] ?>"><?php echo $registros_usuarios['nome'] ?>|<?php echo $registros_usuarios['email'] ?></option>

					<?php } ?>

				</select>

				<input type="button" value="Adicionar" class="btn btn-primary" onclick="GravarTarefaResponsavel(<?php echo $codigo_tarefa ?>)">

			</div>
		</div>
	</div>
</div>