<?php

session_start();
$obterdominio = $_SESSION['dominio'];
include('../' . $obterdominio . '/' . 'conexao.php');
print "teste";
$area = $_POST['area'];
$codigo = $_POST['codigo'];
$titulo = $_POST['titulo'];
$descricao = $_POST['descricao'];
$data_inicio = $_POST['inicio'];
$planoAcao = $_POST['planoAcao'];
$itemQaa = $_POST['itemQaa'];

@$data_min = $_POST['inicio'];
$ano_min = substr($data_min, 6, 10);
$mes_min = substr($data_min, 3, 2);
$dia_min = substr($data_min, 0, 2);

@$data_min = $ano_min . "-" . $mes_min . "-" . $dia_min;








$data_termino = $_POST['termino'];

@$data_max = $_POST['termino'];
$ano_max = substr($data_max, 6, 10);
$mes_max = substr($data_max, 3, 2);
$dia_max = substr($data_max, 0, 2);

@$data_max = $ano_max . "-" . $mes_max . "-" . $dia_max;






$envolvido = $_POST['envolvido'];
$status = $_POST['status'];
$periodicidade = $_POST['periodicidade'];

mysqli_query($conexao, "SET NAMES 'utf8'");
mysqli_query($conexao, 'SET character_set_connection=utf8');
mysqli_query($conexao, 'SET character_set_client=utf8');
mysqli_query($conexao, 'SET character_set_results=utf8');

$sql = "update tarefas_atividades_workflow set tarefa='$titulo', descricao='$descricao', data_inicio='$data_min', data_termino='$data_max', envolvido='$envolvido', status='$status' , periodicidade='$periodicidade', area='$area',planoAcao='$planoAcao, itemQaa='$itemQaa' WHERE id='$codigo'";
die($sql);
$atualizar = mysqli_query($conexao, $sql);
if ($atualizar) {

	$atualizar_anexos = mysqli_query($conexao, "select * from upload_temp_workflow");
	$registros = mysqli_fetch_array($atualizar_anexos);
	$arquivo = $registros['arquivo'];
	$data = date('d-m-Y');
	$hora = date("H:i:s");

	if ($arquivo != '') {

		$novo_anexo = mysqli_query($conexao, "insert into upload_workflow(arquivo,codigo_cadastro,data,hora)values('$arquivo','$codigo','$data','$hora')");
	}

	$excluir = mysqli_query($conexao, "delete  from upload_temp_workflow  ");

?>
	

<?php } else { ?>

	
<?php }

?>
